import random
import math
from re import M
from numba import jit


class kp_genetic:
    def __init__(self, params): 
        self.ALL_NUMBERS = list(range(params["max_per_item"] + 1))
        self.params = params
        self.specimen = [None] * params["generation_size"]
        self.create_initial_population()

    def create_initial_population(self):
        self.specimen = list(map(
            lambda _: list(map(
                lambda _: random.choice(self.ALL_NUMBERS),
                [None] * len(self.params["items"])
            )),
            self.specimen
        ))

    def fitness(self, specimen):

        precio = 0
        peso = 0

        for index, i in enumerate(specimen):
            if i==0:
                continue
            else: 
                peso += self.params["vals"][index]
                precio +=self.params["weis"][index]

        if peso > self.params["max_weight"]:
            return -1
        else: 
            print(precio)
            return precio    

        pass

    def is_converged(self):
        if any(self.fitness(specimen) >= self.params["fit_threshold"] for specimen in self.specimen):
            return True

        return False

    def get_fit(self):
        evaluations = self.fitness_all()

        max_evaluation = max(evaluations)

        max_index = evaluations.index(max_evaluation)

        return self.specimen[max_index], max_evaluation

    def fitness_all(self):
        return list(map(self.fitness, self.specimen))

    def select_specimen(self, specimen_evaluations):
        specimen_and_evaluations = list(zip(self.specimen, specimen_evaluations))

        specimen_and_evaluations.sort(key=lambda e: e[1], reverse = True)

        n_top = int(math.ceil(len(self.specimen) * self.params["select_top"]))

        return list(map(lambda s: s[0], specimen_and_evaluations[:n_top]))
  
    def mutate(self, specimen):
        
        for i in range(self.params["max_per_item"]):
            k=random.uniform(0,1)

            if k< self.params["mutation_percentage"]:
                if specimen[i]==1:
                    specimen[i]=0
                else:
                    specimen[i]=1
        return specimen
       #pass

    def generate_children(self, selected_specimen):  
        mutated_specimen = [None] * len(self.specimen)

        for i in range(len(mutated_specimen)):
            mutated_specimen[i] = self.mutate(random.choice(selected_specimen))

        return mutated_specimen



    def run_genetic(self):
        generation_number = 1
        valeur_opti = 0
        best_ = 0
        valeur_opti = 0
        poids_fin = 0
        while generation_number <= self.params["max_generations"] and not self.is_converged():
            top_generation = self.get_fit()
            top_str = "".join(str(top_generation[0]))

            print(f"Generation #{generation_number}:\t{top_str}\t{top_generation[1]}")

            specimen_evaluations = self.fitness_all()
            selected_specimen = self.select_specimen(specimen_evaluations)

            self.specimen = self.generate_children(selected_specimen)

            generation_number += 1

            res = self.get_fit()

            best_ = res[0]

            valeur_opti = 0
            poids_fin = 0
            for i in range(len(res[0])):
                if best_[i]!=0:
                    valeur_opti += best_[i] * self.params["vals"][i]
                    poids_fin += best_[i] * self.params["weis"][i]
        
        return best_, valeur_opti, poids_fin