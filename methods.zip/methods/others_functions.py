
def get_knapsack_datas(file,directory,racine):
    '''
    Cette méthode permet de récupérer les données contenu dans un dataset
    knapsack 
    exemple :
    - racine="instances_01_KP"
    - directory : size-dimensional
    - file : f00_l-d_kp_00_000
    '''
    V, W, VW = [], [], []
    with open(racine+"/"+directory+"/"+file, "r") as datas:
        for line in datas:
            L = line.split()
            if len(L) == 2 :
                inf , sup = int(L[0]) , int(L[1])
                VW.append((inf, sup))
                V.append(inf)
                W.append(sup)
    Cap = W[0]
    n = V[0]
    return V[1:], W[1:], Cap, VW, n


def get_datas_in_an_other_format(values,weights):
    '''
    Cette focntion construit des Items !!! en paire (V,W)
    '''
    datas = []
    for i in range(len(values)):
        datas.append((values[i],weights[i]))
    return datas