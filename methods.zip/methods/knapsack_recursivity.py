import numpy as np
from numba import jit

@jit(forceobj=True)
def run_recursivity(indeex, items, capacity, ancetre): 
    '''
    Cette méthode renvoie la solution au problème de sac à dos
    en utilisant la récursivité
    '''
    if (indeex == len(items) or capacity <= 0):
        return (0, ancetre)
    else :
        solution1 = run_recursivity(indeex + 1, items, capacity, ancetre)[0]
        solution2 = np.float('inf')
        if capacity - items[indeex][1] >= 0:
            solution2 = run_recursivity(indeex + 1, items, capacity - items[indeex][1], ancetre)[0] + items[indeex][0]
        else :
            solution2 = solution1
        if solution1 >= solution2:
            ancetre[indeex] = 0
        else :
            ancetre[indeex] = 1
        return (max(solution1, solution2), ancetre)
