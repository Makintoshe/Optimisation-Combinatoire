from numba import jit

@jit(forceobj=True)
def run_recursivity_memo(indeex, items, capacity, cache, ancetre): 
    '''
    Cette méthode renvoie la solution au problème de sac à dos
    en utilisant la récursivité avec mémorisation des valeurs
    '''

    if (indeex, capacity) in cache:
        return cache[(indeex, capacity)]

    if (indeex == len(items) or capacity <= 0):
        return (0, ancetre)
    else :
        solution1 = run_recursivity_memo(indeex + 1, items, capacity, cache, ancetre)[0]
        solution2 = float('inf')
        if capacity - items[indeex][1] >= 0:
            solution2 = run_recursivity_memo(indeex + 1, items, capacity - items[indeex][1], cache, ancetre)[0] + items[indeex][0]
        else :
            solution2 = solution1
        if solution1 >= solution2:
            ancetre[indeex] = 0
            cache[(indeex, capacity)] = (solution1, ancetre)
        else :
            ancetre[indeex] = 1
            cache[(indeex, capacity)] = (solution1, ancetre)
        return (max(solution1, solution2), ancetre)
