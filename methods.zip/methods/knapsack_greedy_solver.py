import numpy as np

def evaluation(values, weights):
    '''
    Cette méthode, attribue un score d'importance à chaque item, en se
    basant sur son index. 
    - elle renvoie ensuite les scores onbtenus et rangés selon un ordre 
    croissant : Indexs_sorted_by_score_ 
    - ratio = v_i/w_i
    '''
    importance = np.array([])
    for v in range(len(values)):
        importance = np.append(importance,round((values[v]/weights[v]),3)) 
    Indexs_sorted_by_score_ = np.argsort(-importance)
    
    return Indexs_sorted_by_score_

def run_greedy(values, weights, capacity):
    '''
    Cette méthode applique l'heuristique greedy
    renvoie : Opti_val la valeur solution
    '''

    n = len(values)

    print("valeurs = ",values)
    print("poids = ",weights)
    print("la capacité maximale attendue est = ",capacity,"\n")

    nb_items_sac = 0
    
    # On trie les items en fonction des ratios
    ratios_sorted =  evaluation(values,weights)
    position_items_sac = np.zeros(n).astype(int)
    
    # Ajoute les items avec un grand score d'importance
    for i in range(n):
       index_Items_Important = ratios_sorted[i]
       if((nb_items_sac+weights[index_Items_Important]) <= capacity ):
           position_items_sac[index_Items_Important] = 1 
           nb_items_sac += weights[index_Items_Important]
           print("Ajouter l'item <",values[index_Items_Important],",",weights[index_Items_Important], 
                     "> dans le sac")    
    rangs = position_items_sac

    print("\n position finale de chaque item dans le sac = ",rangs)
    print("\n leurs valeurs respectivent = ", values[rangs==1])
    print("\n leurs poids respectifs = ", weights[rangs==1]) 
    print("\n poid du sac à la solution optimale = " , np.sum(weights[rangs==1]))

    # Retourne la solution optimale

    Opti_val = np.sum(values[rangs==1])

    return Opti_val