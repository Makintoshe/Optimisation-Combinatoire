from importlib.util import cache_from_source
from numba import jit


@jit(forceobj=True)
def run_bottum_up(items, capacity):
    '''
    Cette méthode fait de la programmtion dynamique type-bottom_up
    de la focntion récursive
    '''
    cache = {len(items) : 0}
    i = len(items) - 1
    while i > -1 and capacity > 0:
        solution1 = cache[i + 1]
        solution2 = float('inf')
        if capacity - items[i][1] >= 0:
            capacity = capacity - items[i][1]
            solution2 =  cache[i + 1] + items[i][0]
        else:
            solution2 = solution1
        if solution1 >= solution2:
            cache[i] = solution1
        else :
            cache[i] = solution2
        i -= 1
    return max(solution1, solution2)