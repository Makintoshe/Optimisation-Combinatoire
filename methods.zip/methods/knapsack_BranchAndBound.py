import sys
import numpy as np
import itertools
from dataclasses import dataclass, field
from typing import List
from numba import jit

class TreeNode:
  def __init__(self, level, V, W, taken, not_taken):
    self.level = level # niveau dans l’arbre de recherche >=0
    self.V = V # valeur de la solution courante
    self.W = W # poids de la solution courante
    self.taken = taken # liste des index d’objets de la solution courante
    self.not_taken = not_taken # liste des index d’objets de la solution courante qui n'ont pas été pris
    
  #def __str__(self):
    #return str((self.level, self.V, self.W, self.taken))

class KPBB:
    def __init__(self, cap, values, weights): # Initialisation des données
        self.capacity = cap
        self.values = values
        self.weights = weights
        self.lower_band = 0
        self.unordered = [((v, w), i) for i, (v, w) in enumerate(zip(self.values, self.weights))]
        self.ordered = sorted([((v, w), i) for i, (v, w) in enumerate(zip(self.values, self.weights))], key = lambda tup: float(tup[0][0])/tup[0][1], reverse = True)
  
    def initialSolutionGreedy(self): # calcul de la solution initiale en greedy
        LB =  0
        n = len(self.unordered)
        k = 0
        cap = 0
        while k < n :
            if cap +  self.unordered[k][0][1] <  self.capacity:
                LB += self.unordered[k][0][0]
                cap += self.unordered[k][0][1] 
            k += 1
        return LB

    def initialSolution(self): # calcul de la solution initiale à l'aide de greedy
        capacite = 0
        LowerBound =  0
        for i in range(len(self.values)):
            if self.weights[i] + capacite > self.capacity:
                continue
            else :
                LowerBound = LowerBound + self.values[i]
                capacite = capacite + self.weights[i]
        return LowerBound 

    def nodeEvaluation(self,index, node): # fonction d’évaluation d’un noeud
        values = 0
        poids = 0
        liste_item = list(self.ordered) # On travail avec la liste ordonnée
        for noeud in node.taken: # pour chaque noeud dans la liste des noeuds initilaisé
            # value, weight, position : on récupère, 
            poids = poids + self.unordered[noeud][0][1]
            values = values + self.unordered[noeud][0][0]
            del liste_item[liste_item.index(self.unordered[noeud])]
        for noeud in node.not_taken:
            del liste_item[liste_item.index(self.unordered[noeud])]
        size = len(liste_item)
        iter = 0
        while iter < size and poids < self.capacity:
            if poids + liste_item[iter][0][1] < self.capacity:
                poids = poids + liste_item[iter][0][0] # idem list
                values = values + liste_item[iter][0][1]
            else : 
                values = values + ((self.capacity - poids) / liste_item[iter][0][0]) * liste_item[iter][0][0]
                poids = poids + ((self.capacity - poids) / liste_item[iter][0][1]) * liste_item[iter][0][1]
            iter = iter + 1
        return (values, poids) 

    # solve_Depth_First : resoud le problème du sac à dos avec la méthode de branch and bound en suivant le 
    #                       parcours depth first 
    

    @jit(forceobj=True)
    def solve_(self):
        self.lower_band = self.initialSolution() # initialisation de la lower_band avec greedy
        
        # evaluation du noeud
        idx = -1
        level = 0
        taken = []
        not_taken = []
        root = TreeNode(0, 0, 0, taken, not_taken)
        eva = self.nodeEvaluation(0, root)
        root.V = eva[0]
        root.W = eva[1]
        if root.V <= self.lower_band:
            return self.lower_band
        if root.V % 1 == 0 and root.V > self.lower_band and idx == len(self.ordered) - 1:
            self.lower_band = root.V
            return self.lower_band

        return  self.lower_band