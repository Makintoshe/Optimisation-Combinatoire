def run_knapsack(values, weights, capacity): # calcul de la solution du problème du sac à dos en greedy
        '''
        Cette méthode sert à trouver une solution 
        en implémentant une technique heuristique simple 
        de résolution d'un problème de sac à dos.

        # input params:
            -- values : le vecteur des valeurs d'objets ou items
            -- weights : les poids respectifs de chaque objet ou item
            -- capacity : la capacité maximale attendue par le sac
        
        # Variables :
            -- capacite : c'est la capacité du sac pendant le déroulement de l'algorithme
            -- Opti_val : c'est la valeur optimale

        # output params:
            - Opti_val : valeur optimale ou valeur solution
        '''
        capacite = 0
        Opti_val =  0
        for i in range(len(values)):
            if weights[i] + capacite > capacity:
                continue
            else :
                Opti_val = Opti_val + values[i]
                capacite = capacite + weights[i]
        return Opti_val 